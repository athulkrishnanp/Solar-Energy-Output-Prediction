from django.urls import path
from . import views

urlpatterns = [
path('', views.home, name='home'),
path('login',views.login,name='login'),
path('home', views.home, name='home'),
path('register', views.register, name='register'),
path('loginhandler',views.loginhandler,name='loginhandler'),
path('registerhandler',views.registerhandler,name='registerhandler'),
path('predictionhandler',views.predictionhandler,name='predictionhandler'),
path('userhome',views.userhome,name='userhome'),
path('analysis',views.analysis,name='analysis'),
path('prediction',views.prediction,name='prediction'),
path('result',views.result,name='result'),
]