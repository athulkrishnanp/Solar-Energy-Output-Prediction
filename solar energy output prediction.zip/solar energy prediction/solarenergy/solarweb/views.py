from django.shortcuts import render

def home(request):
    return render(request, 'home.html')

def login(request):
    return render(request, 'login.html')

def register(request):
    return render(request, 'register.html')

def userhome(request):
    return render(request, 'userhome.html')

def prediction(request):
    return render(request, 'prediction.html')

def loginhandler(request):
    import mysql.connector
    a = request.POST.get("n")
    b = request.POST.get("pass")

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="solardb"
    )
    mycursor = mydb.cursor()
    q = "select * from userdata where username=%s and password=%s"

    mycursor.execute(q,(a,b))
    row = mycursor.fetchone()

    if row is not None:
        return render(request, 'userhome.html')
    else:
        return render(request, 'login.html', {"msg": "Invalid Credientials"})

    
from django.shortcuts import render
import mysql.connector

def registerhandler(request):
    if request.method == "POST":
        # Get values from POST (not GET)
        a = request.POST.get("fullname")
        b = request.POST.get("gen")
        c = request.POST.get("mail")
        d = request.POST.get("phonen")
        e = request.POST.get("n")
        f = request.POST.get("pass")

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="solardb"
        )
        mycursor = mydb.cursor()
        q = "INSERT INTO userdata (Name, Gender, Email, Phone, Username, Password) VALUES (%s,%s,%s,%s,%s,%s)"
        mycursor.execute(q, (a, b, c, d, e, f))
        mydb.commit()
        mydb.close()

        return render(request, 'register.html', {"msg": "Registration Successful"})

    # If request method is not POST
    return render(request, 'register.html')


import os
import io
import base64
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from django.conf import settings
from django.shortcuts import render

def analysis(request):

    # ------------------------------
    # Load CSV
    # ------------------------------
    filepath = os.path.join(settings.BASE_DIR, 'solarweb', 'ml_model', 'spg.csv')
    df = pd.read_csv(filepath)

    charts = {}

    def get_graph():
        buffer = io.BytesIO()
        plt.savefig(buffer, format='png', bbox_inches='tight')
        plt.close()
        buffer.seek(0)
        return base64.b64encode(buffer.getvalue()).decode('utf-8')

    # ------------------------------
    # 1️⃣ Graph 1 — Histogram (Custom Color)
    # ------------------------------
    plt.figure(figsize=(10,5))
    sns.histplot(df['generated_power_kw'], kde=True, color="#1B1E7B")  # Green
    plt.title("Generated Power Distribution (kW)")
    plt.xlabel("Generated Power (kW)")
    charts['graph1'] = get_graph()

    # ------------------------------
    # 2️⃣ Graph 2 — Radiation vs Power (Custom Color)
    # ------------------------------
    plt.figure(figsize=(10,5))
    sample_df = df.sample(min(1000, len(df)), random_state=42)
    sns.scatterplot(x='shortwave_radiation_backwards_sfc', y='generated_power_kw', data=sample_df, color="#1B1E7B")
    plt.title("Power vs Solar Radiation")
    plt.xlabel("Solar Radiation")
    plt.ylabel("Generated Power (kW)")
    charts['graph2'] = get_graph()

    # ------------------------------
    # 3️⃣ Graph 3 — Temperature vs Power (Line Plot)
    # ------------------------------
    plt.figure(figsize=(10,5))
    sample_df = df.sample(min(1000, len(df)), random_state=42)
    sns.lineplot(
        x=df['temperature_2_m_above_gnd'],
        y=df['generated_power_kw'],
        data=sample_df,
        color="#1B1E7B" 
    )
    plt.title("Power vs Temperature (Trend Line)")
    plt.xlabel("Temperature (°C)")
    plt.ylabel("Generated Power (kW)")
    charts['graph3'] = get_graph()

    # ------------------------------
    # 4️⃣ Graph 4 — Wind Speed vs Power (Bar Chart)
    # ------------------------------
    df['wind_bins'] = pd.cut(df['wind_speed_10_m_above_gnd'], bins=8)

    plt.figure(figsize=(12,6))
    sns.barplot(
        x='wind_bins',
        y='generated_power_kw',
        data=df,
        ci=None,
        color="#1B1E7B"
    )
    plt.xticks(rotation=45)
    plt.title("Average Power by Wind Speed Bins")
    plt.xlabel("Wind Speed Range (10m)")
    plt.ylabel("Average Generated Power (kW)")
    charts['graph4'] = get_graph()
    
    return render(request, 'analysis.html', charts)


from django.shortcuts import render
import numpy as np
import pandas as pd
import pickle
import os

# Load the model when the server starts
MODEL_PATH = os.path.join(os.path.dirname(__file__),"ml_model", "solar_model.pkl")
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

# Label mapping for classified output
label_map = {
    0: "Very Low Power",
    1: "Low Power",
    2: "Medium Power",
    3: "High / Peak Power"
}

def predictionhandler(request):
    if request.method == "POST":

        # Get values from the HTML form
        temp = float(request.POST.get("temperature"))
        humidity = float(request.POST.get("humidity"))
        radiation = float(request.POST.get("radiation"))
        cloud = float(request.POST.get("cloud"))
        wind = float(request.POST.get("wind"))
        angle = float(request.POST.get("angle"))
        zen = float(request.POST.get("zenith"))
        azi = float(request.POST.get("azimuth"))

        # Create a pandas DataFrame for prediction
        new_input = pd.DataFrame([{
            'temperature_2_m_above_gnd': temp,
            'relative_humidity_2_m_above_gnd': humidity,
            'shortwave_radiation_backwards_sfc': radiation,
            'total_cloud_cover_sfc': cloud,
            'wind_speed_10_m_above_gnd': wind,
            'angle_of_incidence': angle,
            'zenith': zen,
            'azimuth': azi
        }])

        # Predict the class
        pred_class = model.predict(new_input)[0]

        # Convert numeric class → text label
        predicted_label = label_map[pred_class]

        return render(request, "result.html", {
            "predicted_class": pred_class,
            "predicted_label": predicted_label,
            "temp": temp,
            "humidity": humidity,
            "radiation": radiation,
            "cloud": cloud,
            "wind": wind,
            "angle": angle,
            "zen": zen,
            "azi": azi
        })

    return render(request, "prediction.html")

def result(request):
    return render(request,'result.html')