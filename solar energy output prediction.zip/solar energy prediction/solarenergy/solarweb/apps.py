from django.apps import AppConfig


class SolarwebConfig(AppConfig):
    name = 'solarweb'
